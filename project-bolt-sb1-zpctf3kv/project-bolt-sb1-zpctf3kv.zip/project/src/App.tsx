import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, 
  MapPin, 
  Car, 
  Clock, 
  TrendingUp, 
  Settings,
  Power,
  AlertCircle,
  CheckCircle,
  Home,
  Camera,
  BarChart3,
  Menu,
  X,
  Navigation,
  Zap
} from 'lucide-react';

// Chart.js types
declare var Chart: any;

interface TrafficData {
  kpis: {
    avgCommuteTime: number;
    totalVehicles: number;
    congestionIndex: number;
    commuteReduction: number;
    activeIntersections: number;
    systemUptime: number;
  };
  systemStatus: 'active' | 'manual' | 'offline';
  intersections: {
    [key: string]: {
      id: string;
      name: string;
      coordinates: { x: number; y: number };
      status: 'optimal' | 'congested' | 'critical';
      queues: {
        northSouth: number;
        eastWest: number;
        westEast: number;
        southNorth: number;
      };
      signalTiming: {
        currentPhase: 'ns-green' | 'ew-green' | 'transition';
        timeRemaining: number;
      };
      aiOptimization: number;
    };
  };
  performance: {
    aiWaitTimes: number[];
    fixedWaitTimes: number[];
    efficiencyGain: number;
    throughputImprovement: number;
  };
}

type PageType = 'dashboard' | 'cameras' | 'analytics' | 'controls';

function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [selectedIntersection, setSelectedIntersection] = useState<string>('1');
  const [aiEnabled, setAiEnabled] = useState(true);
  const [manualTiming, setManualTiming] = useState({ nsGreen: 30, ewGreen: 25 });
  
  const waitTimeChartRef = useRef<any>(null);
  const efficiencyChartRef = useRef<any>(null);
  const throughputChartRef = useRef<any>(null);

  const [trafficData, setTrafficData] = useState<TrafficData>({
    kpis: {
      avgCommuteTime: 18.5,
      totalVehicles: 24750,
      congestionIndex: 4.2,
      commuteReduction: 23,
      activeIntersections: 12,
      systemUptime: 99.7
    },
    systemStatus: 'active',
    intersections: {
      '1': {
        id: '1',
        name: 'Downtown Core - Main St & 1st Ave',
        coordinates: { x: 320, y: 180 },
        status: 'optimal',
        queues: { northSouth: 8, eastWest: 12, westEast: 6, southNorth: 4 },
        signalTiming: { currentPhase: 'ns-green', timeRemaining: 25 },
        aiOptimization: 87
      },
      '2': {
        id: '2', 
        name: 'Business District - Commerce Blvd & 2nd Ave',
        coordinates: { x: 480, y: 140 },
        status: 'congested',
        queues: { northSouth: 18, eastWest: 22, westEast: 15, southNorth: 11 },
        signalTiming: { currentPhase: 'ew-green', timeRemaining: 18 },
        aiOptimization: 92
      },
      '3': {
        id: '3',
        name: 'Highway Junction - I-95 & Central Pkwy',
        coordinates: { x: 200, y: 120 },
        status: 'critical',
        queues: { northSouth: 35, eastWest: 28, westEast: 31, southNorth: 19 },
        signalTiming: { currentPhase: 'transition', timeRemaining: 3 },
        aiOptimization: 78
      },
      '4': {
        id: '4',
        name: 'Residential Hub - Oak St & Park Ave',
        coordinates: { x: 380, y: 280 },
        status: 'optimal',
        queues: { northSouth: 5, eastWest: 8, westEast: 3, southNorth: 7 },
        signalTiming: { currentPhase: 'ns-green', timeRemaining: 32 },
        aiOptimization: 94
      },
      '5': {
        id: '5',
        name: 'Shopping Center - Mall Dr & Retail Rd',
        coordinates: { x: 520, y: 240 },
        status: 'congested',
        queues: { northSouth: 24, eastWest: 16, westEast: 20, southNorth: 13 },
        signalTiming: { currentPhase: 'ew-green', timeRemaining: 12 },
        aiOptimization: 85
      },
      '6': {
        id: '6',
        name: 'University District - College Ave & Academic Way',
        coordinates: { x: 160, y: 220 },
        status: 'optimal',
        queues: { northSouth: 9, eastWest: 6, westEast: 11, southNorth: 8 },
        signalTiming: { currentPhase: 'ns-green', timeRemaining: 28 },
        aiOptimization: 91
      }
    },
    performance: {
      aiWaitTimes: [32, 28, 25, 22, 19, 17, 15, 14],
      fixedWaitTimes: [45, 44, 43, 42, 41, 40, 39, 38],
      efficiencyGain: 38,
      throughputImprovement: 42
    }
  });

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setTrafficData(prevData => {
        const variation = () => (Math.random() - 0.5) * 0.2;
        
        return {
          ...prevData,
          kpis: {
            ...prevData.kpis,
            avgCommuteTime: Math.max(12, prevData.kpis.avgCommuteTime + variation() * 3),
            totalVehicles: Math.floor(prevData.kpis.totalVehicles + Math.random() * 200 - 100),
            congestionIndex: Math.max(1, Math.min(10, prevData.kpis.congestionIndex + variation() * 1.5)),
            commuteReduction: Math.max(15, Math.min(35, prevData.kpis.commuteReduction + variation() * 2))
          },
          intersections: Object.fromEntries(
            Object.entries(prevData.intersections).map(([key, intersection]) => [
              key,
              {
                ...intersection,
                queues: {
                  northSouth: Math.max(0, Math.floor(intersection.queues.northSouth + variation() * 8)),
                  eastWest: Math.max(0, Math.floor(intersection.queues.eastWest + variation() * 8)),
                  westEast: Math.max(0, Math.floor(intersection.queues.westEast + variation() * 8)),
                  southNorth: Math.max(0, Math.floor(intersection.queues.southNorth + variation() * 8))
                },
                signalTiming: {
                  ...intersection.signalTiming,
                  timeRemaining: Math.max(1, intersection.signalTiming.timeRemaining - 1)
                }
              }
            ])
          )
        };
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // Initialize charts
  useEffect(() => {
    if (currentPage === 'analytics') {
      setTimeout(() => {
        initializeCharts();
      }, 100);
    }
  }, [currentPage, trafficData]);

  const initializeCharts = () => {
    // Wait Time Chart
    if (waitTimeChartRef.current) {
      const ctx = waitTimeChartRef.current.getContext('2d');
      new Chart(ctx, {
        type: 'line',
        data: {
          labels: ['8h ago', '7h ago', '6h ago', '5h ago', '4h ago', '3h ago', '2h ago', '1h ago'],
          datasets: [
            {
              label: 'AI System',
              data: trafficData.performance.aiWaitTimes,
              borderColor: '#3B82F6',
              backgroundColor: 'rgba(59, 130, 246, 0.1)',
              tension: 0.4,
              fill: true,
              pointBackgroundColor: '#3B82F6',
              pointBorderColor: '#1E40AF',
              pointRadius: 4
            },
            {
              label: 'Fixed Timing',
              data: trafficData.performance.fixedWaitTimes,
              borderColor: '#EF4444',
              backgroundColor: 'rgba(239, 68, 68, 0.1)',
              tension: 0.4,
              fill: true,
              pointBackgroundColor: '#EF4444',
              pointBorderColor: '#DC2626',
              pointRadius: 4
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              labels: { 
                color: '#E5E7EB',
                font: { size: 12, family: 'Inter' }
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              grid: { color: 'rgba(75, 85, 99, 0.3)' },
              ticks: { 
                color: '#9CA3AF',
                font: { family: 'Inter' }
              }
            },
            x: {
              grid: { color: 'rgba(75, 85, 99, 0.3)' },
              ticks: { 
                color: '#9CA3AF',
                font: { family: 'Inter' }
              }
            }
          }
        }
      });
    }

    // Efficiency Chart
    if (efficiencyChartRef.current) {
      const ctx = efficiencyChartRef.current.getContext('2d');
      new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: ['AI Efficiency', 'Traditional'],
          datasets: [{
            data: [trafficData.performance.efficiencyGain, 100 - trafficData.performance.efficiencyGain],
            backgroundColor: ['#10B981', '#374151'],
            borderColor: ['#059669', '#4B5563'],
            borderWidth: 2
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: { 
                color: '#E5E7EB',
                font: { size: 12, family: 'Inter' }
              }
            }
          }
        }
      });
    }

    // Throughput Chart
    if (throughputChartRef.current) {
      const ctx = throughputChartRef.current.getContext('2d');
      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          datasets: [{
            label: 'Throughput Improvement (%)',
            data: [42, 38, 45, 41, 47, 35, 29],
            backgroundColor: 'rgba(59, 130, 246, 0.8)',
            borderColor: '#3B82F6',
            borderWidth: 1,
            borderRadius: 4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              labels: { 
                color: '#E5E7EB',
                font: { family: 'Inter' }
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              grid: { color: 'rgba(75, 85, 99, 0.3)' },
              ticks: { 
                color: '#9CA3AF',
                font: { family: 'Inter' }
              }
            },
            x: {
              grid: { color: 'rgba(75, 85, 99, 0.3)' },
              ticks: { 
                color: '#9CA3AF',
                font: { family: 'Inter' }
              }
            }
          }
        }
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-emerald-500';
      case 'manual': return 'bg-amber-500';
      case 'offline': return 'bg-red-500';
      default: return 'bg-slate-500';
    }
  };

  const getIntersectionStatusColor = (status: string) => {
    switch (status) {
      case 'optimal': return '#10B981';
      case 'congested': return '#F59E0B';
      case 'critical': return '#EF4444';
      default: return '#6B7280';
    }
  };

  const navigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'cameras', label: 'Camera Feeds', icon: Camera },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'controls', label: 'System Controls', icon: Settings }
  ];

  const renderNavigation = () => (
    <nav className="bg-slate-900 border-b border-slate-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Activity className="w-8 h-8 text-blue-400 mr-3" />
              <h1 className="text-xl font-bold text-white">TrafficAI Control</h1>
            </div>
            <div className="hidden md:ml-10 md:flex md:space-x-8">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentPage(item.id as PageType)}
                    className={`inline-flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      currentPage === item.id
                        ? 'bg-blue-600 text-white'
                        : 'text-slate-300 hover:text-white hover:bg-slate-700'
                    }`}
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {item.label}
                  </button>
                );
              })}
            </div>
          </div>
          
          <div className="flex items-center">
            <div className="flex items-center space-x-3 mr-4">
              <div className={`w-2 h-2 rounded-full ${getStatusColor(trafficData.systemStatus)}`}></div>
              <span className="text-sm text-slate-300 capitalize">{trafficData.systemStatus}</span>
            </div>
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-slate-400 hover:text-white p-2"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-800 border-t border-slate-700">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id as PageType);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center w-full px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    currentPage === item.id
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700'
                  }`}
                >
                  <Icon className="w-4 h-4 mr-2" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </nav>
  );

  const renderCityMap = (showIntersectionDetails = false) => (
    <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-white flex items-center">
          <MapPin className="w-5 h-5 mr-2 text-blue-400" />
          City Traffic Network
        </h2>
        <div className="flex items-center space-x-4 text-sm">
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-emerald-500 mr-2"></div>
            <span className="text-slate-300">Optimal</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-amber-500 mr-2"></div>
            <span className="text-slate-300">Congested</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
            <span className="text-slate-300">Critical</span>
          </div>
        </div>
      </div>
      
      <div className="relative bg-slate-900 rounded-lg overflow-hidden" style={{ height: '400px' }}>
        <svg width="100%" height="100%" viewBox="0 0 640 400" className="absolute inset-0">
          {/* City Background */}
          <rect width="640" height="400" fill="#0F172A" />
          
          {/* City Blocks */}
          <rect x="50" y="50" width="120" height="80" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          <rect x="200" y="50" width="100" height="60" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          <rect x="330" y="40" width="140" height="90" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          <rect x="500" y="60" width="90" height="70" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          
          <rect x="60" y="160" width="90" height="100" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          <rect x="180" y="180" width="110" height="80" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          <rect x="320" y="160" width="130" height="110" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          <rect x="480" y="170" width="100" height="90" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          
          <rect x="70" y="290" width="100" height="80" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          <rect x="200" y="300" width="120" height="70" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          <rect x="350" y="290" width="110" height="85" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          <rect x="490" y="280" width="120" height="90" fill="#1E293B" stroke="#334155" strokeWidth="1" />
          
          {/* Major Roads */}
          <line x1="0" y1="140" x2="640" y2="140" stroke="#475569" strokeWidth="8" />
          <line x1="0" y1="280" x2="640" y2="280" stroke="#475569" strokeWidth="8" />
          <line x1="180" y1="0" x2="180" y2="400" stroke="#475569" strokeWidth="8" />
          <line x1="320" y1="0" x2="320" y2="400" stroke="#475569" strokeWidth="8" />
          <line x1="480" y1="0" x2="480" y2="400" stroke="#475569" strokeWidth="8" />
          
          {/* Secondary Roads */}
          <line x1="0" y1="220" x2="640" y2="220" stroke="#64748B" strokeWidth="4" />
          <line x1="380" y1="0" x2="380" y2="400" stroke="#64748B" strokeWidth="4" />
          <line x1="520" y1="0" x2="520" y2="400" stroke="#64748B" strokeWidth="4" />
          
          {/* Highway */}
          <line x1="0" y1="120" x2="640" y2="120" stroke="#3B82F6" strokeWidth="6" />
          
          {/* Intersections */}
          {Object.entries(trafficData.intersections).map(([key, intersection]) => (
            <g key={key}>
              <circle
                cx={intersection.coordinates.x}
                cy={intersection.coordinates.y}
                r="12"
                fill={getIntersectionStatusColor(intersection.status)}
                stroke="#1E293B"
                strokeWidth="2"
                className="cursor-pointer hover:opacity-80 transition-opacity"
                onClick={() => setSelectedIntersection(key)}
              />
              <circle
                cx={intersection.coordinates.x}
                cy={intersection.coordinates.y}
                r="4"
                fill="white"
                className="pointer-events-none"
              />
              <text
                x={intersection.coordinates.x}
                y={intersection.coordinates.y - 20}
                textAnchor="middle"
                fill="#E2E8F0"
                fontSize="10"
                fontFamily="Inter"
                className="pointer-events-none"
              >
                {intersection.id}
              </text>
            </g>
          ))}
          
          {/* Traffic Flow Indicators */}
          <defs>
            <marker id="arrowhead" markerWidth="10" markerHeight="7" 
             refX="0" refY="3.5" orient="auto">
              <polygon points="0 0, 10 3.5, 0 7" fill="#10B981" />
            </marker>
          </defs>
          
          {/* Flow arrows on major roads */}
          <line x1="50" y1="135" x2="80" y2="135" stroke="#10B981" strokeWidth="2" markerEnd="url(#arrowhead)" />
          <line x1="250" y1="145" x2="280" y2="145" stroke="#10B981" strokeWidth="2" markerEnd="url(#arrowhead)" />
          <line x1="400" y1="135" x2="430" y2="135" stroke="#10B981" strokeWidth="2" markerEnd="url(#arrowhead)" />
          
          <line x1="185" y1="50" x2="185" y2="80" stroke="#10B981" strokeWidth="2" markerEnd="url(#arrowhead)" />
          <line x1="325" y1="200" x2="325" y2="230" stroke="#10B981" strokeWidth="2" markerEnd="url(#arrowhead)" />
        </svg>
        
        {showIntersectionDetails && selectedIntersection && (
          <div className="absolute top-4 right-4 bg-slate-800 border border-slate-600 rounded-lg p-4 max-w-xs">
            <h3 className="font-semibold text-white mb-2">
              {trafficData.intersections[selectedIntersection]?.name}
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-400">Status:</span>
                <span className={`font-medium ${
                  trafficData.intersections[selectedIntersection]?.status === 'optimal' ? 'text-emerald-400' :
                  trafficData.intersections[selectedIntersection]?.status === 'congested' ? 'text-amber-400' :
                  'text-red-400'
                }`}>
                  {trafficData.intersections[selectedIntersection]?.status}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">AI Optimization:</span>
                <span className="text-blue-400 font-medium">
                  {trafficData.intersections[selectedIntersection]?.aiOptimization}%
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-6">
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Avg Commute</p>
              <p className="text-2xl font-bold text-white">{trafficData.kpis.avgCommuteTime.toFixed(1)}m</p>
              <p className="text-emerald-400 text-sm font-medium">-{trafficData.kpis.commuteReduction}%</p>
            </div>
            <Clock className="w-8 h-8 text-blue-400" />
          </div>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Vehicles Today</p>
              <p className="text-2xl font-bold text-white">{trafficData.kpis.totalVehicles.toLocaleString()}</p>
              <p className="text-slate-400 text-sm">+2.3% vs yesterday</p>
            </div>
            <Car className="w-8 h-8 text-emerald-400" />
          </div>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Congestion Index</p>
              <p className="text-2xl font-bold text-white">{trafficData.kpis.congestionIndex.toFixed(1)}/10</p>
              <p className="text-amber-400 text-sm">Moderate</p>
            </div>
            <TrendingUp className="w-8 h-8 text-amber-400" />
          </div>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">Active Intersections</p>
              <p className="text-2xl font-bold text-white">{trafficData.kpis.activeIntersections}</p>
              <p className="text-emerald-400 text-sm">All operational</p>
            </div>
            <Navigation className="w-8 h-8 text-purple-400" />
          </div>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">System Uptime</p>
              <p className="text-2xl font-bold text-white">{trafficData.kpis.systemUptime}%</p>
              <p className="text-emerald-400 text-sm">Excellent</p>
            </div>
            <Zap className="w-8 h-8 text-yellow-400" />
          </div>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm font-medium">AI Efficiency</p>
              <p className="text-2xl font-bold text-white">{trafficData.performance.efficiencyGain}%</p>
              <p className="text-emerald-400 text-sm">vs traditional</p>
            </div>
            <Activity className="w-8 h-8 text-blue-400" />
          </div>
        </div>
      </div>

      {/* Map and Live Data */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          {renderCityMap(true)}
        </div>
        
        <div className="space-y-6">
          {/* Live Intersection Details */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">
              Intersection Details
            </h3>
            {selectedIntersection && trafficData.intersections[selectedIntersection] && (
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-white text-sm mb-2">
                    {trafficData.intersections[selectedIntersection].name}
                  </h4>
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${
                      trafficData.intersections[selectedIntersection].status === 'optimal' ? 'bg-emerald-500' :
                      trafficData.intersections[selectedIntersection].status === 'congested' ? 'bg-amber-500' :
                      'bg-red-500'
                    }`}></div>
                    <span className="text-slate-300 text-sm capitalize">
                      {trafficData.intersections[selectedIntersection].status}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-slate-700 rounded-lg p-3">
                    <div className="text-xs text-slate-400 mb-1">North-South</div>
                    <div className="text-lg font-semibold text-blue-400">
                      {trafficData.intersections[selectedIntersection].queues.northSouth}
                    </div>
                  </div>
                  <div className="bg-slate-700 rounded-lg p-3">
                    <div className="text-xs text-slate-400 mb-1">East-West</div>
                    <div className="text-lg font-semibold text-emerald-400">
                      {trafficData.intersections[selectedIntersection].queues.eastWest}
                    </div>
                  </div>
                  <div className="bg-slate-700 rounded-lg p-3">
                    <div className="text-xs text-slate-400 mb-1">West-East</div>
                    <div className="text-lg font-semibold text-amber-400">
                      {trafficData.intersections[selectedIntersection].queues.westEast}
                    </div>
                  </div>
                  <div className="bg-slate-700 rounded-lg p-3">
                    <div className="text-xs text-slate-400 mb-1">South-North</div>
                    <div className="text-lg font-semibold text-purple-400">
                      {trafficData.intersections[selectedIntersection].queues.southNorth}
                    </div>
                  </div>
                </div>

                <div className="bg-slate-700 rounded-lg p-3">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs text-slate-400">Current Signal</span>
                    <span className="text-xs text-slate-300">
                      {trafficData.intersections[selectedIntersection].signalTiming.timeRemaining}s remaining
                    </span>
                  </div>
                  <div className="text-sm font-medium text-white capitalize">
                    {trafficData.intersections[selectedIntersection].signalTiming.currentPhase.replace('-', ' ')}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Quick Stats */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">System Overview</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-slate-400 text-sm">Optimal Intersections</span>
                <span className="text-emerald-400 font-medium">
                  {Object.values(trafficData.intersections).filter(i => i.status === 'optimal').length}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 text-sm">Congested Intersections</span>
                <span className="text-amber-400 font-medium">
                  {Object.values(trafficData.intersections).filter(i => i.status === 'congested').length}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 text-sm">Critical Intersections</span>
                <span className="text-red-400 font-medium">
                  {Object.values(trafficData.intersections).filter(i => i.status === 'critical').length}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400 text-sm">Average AI Optimization</span>
                <span className="text-blue-400 font-medium">
                  {Math.round(Object.values(trafficData.intersections).reduce((acc, i) => acc + i.aiOptimization, 0) / Object.values(trafficData.intersections).length)}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCameras = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Camera Feeds</h2>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
          <span className="text-slate-300 text-sm">Live</span>
        </div>
      </div>

      {/* Map */}
      <div className="mb-6">
        {renderCityMap()}
      </div>

      {/* Camera Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.entries(trafficData.intersections).map(([key, intersection]) => (
          <div key={key} className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-white text-sm">{intersection.name}</h3>
                <div className={`w-2 h-2 rounded-full ${
                  intersection.status === 'optimal' ? 'bg-emerald-500' :
                  intersection.status === 'congested' ? 'bg-amber-500' :
                  'bg-red-500'
                }`}></div>
              </div>
            </div>
            
            <div className="relative bg-slate-900 h-48 flex items-center justify-center">
              {/* Simulated camera feed */}
              <div className="absolute inset-0 bg-gradient-to-br from-slate-800 to-slate-900"></div>
              <div className="relative z-10 text-center">
                <Camera className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                <div className="text-slate-400 text-sm">Camera Feed {intersection.id}</div>
                <div className="text-xs text-slate-500 mt-1">
                  {intersection.coordinates.x}x{intersection.coordinates.y}
                </div>
              </div>
              
              {/* Overlay info */}
              <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 rounded px-2 py-1">
                <div className="text-white text-xs">
                  Queue: {Object.values(intersection.queues).reduce((a, b) => a + b, 0)} vehicles
                </div>
              </div>
              
              <div className="absolute top-2 right-2 bg-black bg-opacity-50 rounded px-2 py-1">
                <div className="text-white text-xs">
                  AI: {intersection.aiOptimization}%
                </div>
              </div>
            </div>
            
            <div className="p-4">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">N-S:</span>
                  <span className="text-blue-400">{intersection.queues.northSouth}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">E-W:</span>
                  <span className="text-emerald-400">{intersection.queues.eastWest}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">W-E:</span>
                  <span className="text-amber-400">{intersection.queues.westEast}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">S-N:</span>
                  <span className="text-purple-400">{intersection.queues.southNorth}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAnalytics = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Performance Analytics</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Wait Time Comparison</h3>
          <div className="h-64">
            <canvas ref={waitTimeChartRef}></canvas>
          </div>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">AI Efficiency</h3>
          <div className="h-64">
            <canvas ref={efficiencyChartRef}></canvas>
          </div>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Weekly Throughput Improvement</h3>
          <div className="h-64">
            <canvas ref={throughputChartRef}></canvas>
          </div>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Performance Metrics</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-slate-700 rounded-lg">
              <span className="text-slate-300">Average Wait Time Reduction</span>
              <span className="text-emerald-400 font-semibold">
                {((trafficData.performance.fixedWaitTimes[7] - trafficData.performance.aiWaitTimes[7]) / trafficData.performance.fixedWaitTimes[7] * 100).toFixed(1)}%
              </span>
            </div>
            <div className="flex justify-between items-center p-3 bg-slate-700 rounded-lg">
              <span className="text-slate-300">Throughput Improvement</span>
              <span className="text-blue-400 font-semibold">{trafficData.performance.throughputImprovement}%</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-slate-700 rounded-lg">
              <span className="text-slate-300">Fuel Savings Estimate</span>
              <span className="text-emerald-400 font-semibold">2,340L/day</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-slate-700 rounded-lg">
              <span className="text-slate-300">CO2 Reduction</span>
              <span className="text-emerald-400 font-semibold">5.2 tons/day</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderControls = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">System Controls</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* AI System Control */}
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">AI System Control</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-700 rounded-lg">
              <div>
                <div className="font-medium text-white">AI Traffic Management</div>
                <div className="text-sm text-slate-400">
                  {aiEnabled ? 'AI is actively managing traffic signals' : 'Manual control is active'}
                </div>
              </div>
              <button
                onClick={() => setAiEnabled(!aiEnabled)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  aiEnabled ? 'bg-blue-600' : 'bg-slate-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    aiEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="p-4 bg-slate-700 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white font-medium">System Status</span>
                <div className="flex items-center space-x-2">
                  {trafficData.systemStatus === 'active' ? (
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                  ) : trafficData.systemStatus === 'manual' ? (
                    <Settings className="w-5 h-5 text-amber-400" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-400" />
                  )}
                  <span className="text-slate-300 capitalize">{trafficData.systemStatus}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Manual Override */}
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Manual Override</h3>
          
          <div className="space-y-4">
            <div className="p-4 bg-slate-700 rounded-lg">
              <label className="block text-sm font-medium text-white mb-2">
                North-South Green Time: {manualTiming.nsGreen}s
              </label>
              <input
                type="range"
                min="15"
                max="60"
                value={manualTiming.nsGreen}
                onChange={(e) => setManualTiming({...manualTiming, nsGreen: parseInt(e.target.value)})}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                disabled={aiEnabled}
              />
            </div>

            <div className="p-4 bg-slate-700 rounded-lg">
              <label className="block text-sm font-medium text-white mb-2">
                East-West Green Time: {manualTiming.ewGreen}s
              </label>
              <input
                type="range"
                min="15"
                max="60"
                value={manualTiming.ewGreen}
                onChange={(e) => setManualTiming({...manualTiming, ewGreen: parseInt(e.target.value)})}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                disabled={aiEnabled}
              />
            </div>

            {aiEnabled && (
              <div className="p-3 bg-amber-900 bg-opacity-20 border border-amber-500 rounded-lg">
                <div className="flex items-center">
                  <AlertCircle className="w-4 h-4 text-amber-400 mr-2" />
                  <span className="text-amber-400 text-sm">
                    Manual controls disabled while AI is active
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Emergency Controls */}
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Emergency Controls</h3>
          
          <div className="space-y-3">
            <button className="w-full bg-red-600 hover:bg-red-700 text-white font-medium py-3 px-4 rounded-lg transition-colors">
              Emergency Stop All Signals
            </button>
            <button className="w-full bg-amber-600 hover:bg-amber-700 text-white font-medium py-3 px-4 rounded-lg transition-colors">
              Switch to Manual Mode
            </button>
            <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-colors">
              Reset AI System
            </button>
          </div>
        </div>

        {/* System Information */}
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">System Information</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-slate-400">Version</span>
              <span className="text-white">v2.1.4</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Last Update</span>
              <span className="text-white">2 hours ago</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Uptime</span>
              <span className="text-emerald-400">99.7%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Active Connections</span>
              <span className="text-white">12/12</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return renderDashboard();
      case 'cameras':
        return renderCameras();
      case 'analytics':
        return renderAnalytics();
      case 'controls':
        return renderControls();
      default:
        return renderDashboard();
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {renderNavigation()}
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderCurrentPage()}
      </main>
    </div>
  );
}

export default App;